/*
                   _ooOoo_
                  o8888888o
                  88" . "88
                  (| -_- |)
                  O\  =  /O
               ____/`---'\____
             .'  \\|     |//  `.
            /  \\|||  :  |||//  \
           /  _||||| -:- |||||-  \
           |   | \\\  -  /// |   |
           | \_|  ''\---/''  |   |
           \  .-\__  `-`  ___/-. /
         ___`. .'  /--.--\  `. . __
      ."" '<  `.___\_<|>_/___.'  >'"".
     | | :  `- \`.;`\ _ /`;.`/ - ` : | |
     \  \ `-.   \_ __\ /__ _/   .-` /  /
======`-.____`-.___\_____/___.-`____.-'======
                   `=---='
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
             佛祖保佑    永无BUG
*/
/**
 * @file    mate.c
 * @brief   ROV主控制循环 (Task)
 * @note    此文件负责统筹数据流向。将遥控器数据和IMU传感器数据进行采集，
 * 交由PID控制器和动力分配引擎(move.c)计算后，最终转化为PWM信号输出给定时器。
 */

#include "Mate.h"
#include "PID.h"
#include "Move.h"
#include "imu.h"
#include "usart.h"
#include <string.h>
#include "RC.h"
#include "tim.h"
#include "iwdg.h" 

// 核心参数：电调中立点 (死区中值)
float midvalue = 1488;
float yaw_target = 0;

extern PID_TYPE PID_pit,PID_yaw,PID_rol;

extern uint8_t RCflag;
extern uint32_t RC_Disconnecttimes;
extern FLOAT_Angle preangle;
extern IWDG_HandleTypeDef hiwdg;

uint16_t motor_outputs1[8];

#define MOTOR_OUTPUT_LIMIT 400.0f 

/**
 * @brief PWM硬件绝对限幅
 */
float constrain(float a){
    if( a > 1900 ){
        a = 1900;
    }
    else if( a < 1100 ){
        a = 1100;
    }
    return a;
}

void Mate_Init(void){
    
    PID_Init(&PID_yaw, 0.5, 0.0, 0.0, -50, 50);
    PID_Init(&PID_pit, 2.5, 0.0, 0.0, -180, 180);
    PID_Init(&PID_rol, 1.2, 0.0, 0.0, -80, 80);
    h30_configure();
    MX_IWDG_Init();
    
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);  // M1
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);  // M2
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);  // M3
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);  // M4
    HAL_TIM_PWM_Start(&htim12, TIM_CHANNEL_1); // M5
    HAL_TIM_PWM_Start(&htim12, TIM_CHANNEL_2); // M6
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);  // M7
    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);  // M8

    // 写入初始中位值解锁电调
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, midvalue);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, midvalue);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, midvalue);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, midvalue);
    __HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_1, midvalue);
    __HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_2, midvalue);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, midvalue);
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, midvalue);
}

void Mate_Task(void)
{
    // 0. 看门狗喂狗与IMU标志位复位
    HAL_IWDG_Refresh(&hiwdg);
    if (imu_data_ready) {    
        imu_data_ready = 0;  
    }
        
    HAL_Delay(10); 
        
    // 1. 动作意图解析 
    // 舵机处理
    RCServo_Calc(MyRCKey); 
    
    // 解析遥控器推杆并转化为目标受力 (X, Y, Z, Roll, Pitch, Yaw)
    float TargetWrench[6] = {0}; 
    RC_To_Target_Wrench(TargetWrench, MyRCKey); 
        
    // 2. 计算姿态 PID 
    PID_Postion_Cal(&PID_yaw, yaw_target, Angle_Measure.yaw);
    PID_Postion_Cal(&PID_rol, 0, Angle_Measure.rol);
    PID_Postion_Cal(&PID_pit, 0, Angle_Measure.pit);
        
    // 将 PID 补偿结果打包
    float PID_Wrench[3] = {PID_rol.OutPut, PID_pit.OutPut, PID_yaw.OutPut};

    // 3. 核心：动态动力分配
    float MotorOut[8] = {0}; 
    
    // 调用全矢量动态动力分配器
    Dynamic_Power_Allocation(MotorOut, TargetWrench, PID_Wrench, MOTOR_OUTPUT_LIMIT);
        
    // 叠加电调中位值 (1488)，并限制在 1100~1900 之间
    for(int i = 0; i < 8; i++) {
        motor_outputs1[i] = constrain(midvalue + MotorOut[i]); 
    }
        
    // 4. 驱动硬件,输出 PWM
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, motor_outputs1[0]); // M1
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, motor_outputs1[1]); // M2
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, motor_outputs1[2]); // M3
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, motor_outputs1[3]); // M4
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, motor_outputs1[4]); // M5
    __HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_2, motor_outputs1[5]); // M6
    __HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_1, motor_outputs1[6]); // M7
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, motor_outputs1[7]); // M8  
        
    HAL_IWDG_Refresh(&hiwdg);
}
