#ifndef __MOTOR_H
#define __MOTOR_H

#include "main.h"
#include "stm32f4xx_hal.h"
 

extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim8;
typedef enum {
    MOTOR_T1 = 0,
    MOTOR_T2,
    MOTOR_T3,
    MOTOR_T4,
    MOTOR_T5,
    MOTOR_T6,
	  MOTOR_T7,
    MOTOR_T8,
    MOTOR_COUNT
} Motor_ID;

extern uint16_t motor_outputs[MOTOR_COUNT];

static uint16_t constrain_pwm(uint16_t pwm);
void Motor_Init(void);
void Motor_stay(void);
void Motor_SetPWM(Motor_ID motor, uint16_t pwm_us);
void Motor_SetAllPWM(uint16_t motor_outputs[MOTOR_COUNT]);
void Motor_StopAll(void);

#endif
