#ifndef __MATE_H
#define __MATE_H
#include "PID.h"
#include "Motor.h"
#include "Move.h"

void Mate_Task(void);
void Mate_Init(void);
float constrain(float a);

#endif
