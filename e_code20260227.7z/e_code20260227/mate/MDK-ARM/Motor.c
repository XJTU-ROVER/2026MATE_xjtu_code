#include "motor.h"
#include "main.h"
#include "stm32f4xx_hal.h"

uint16_t motor_outputs[MOTOR_COUNT];
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim1;
static uint16_t constrain_pwm(uint16_t pwm) {
    if (pwm < 1000) return 1000;
    if (pwm > 2000) return 2000;
    return pwm;
}

// ��ʼ�����PWM
void Motor_Init(void) {
     HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1); // ���1
     HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2); // ���2
     HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3); // ���3
     HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4); // ���4
     HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1); // ���5
     HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2); // ���6
     HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3); // ���5
     HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4); // ���6
	   HAL_Delay(3000);
	
     __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 1488);
     __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 1488);
     __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 1488);
     __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, 1488);
     __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 1488);
     __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, 1488);
	   __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 1488);
     __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 1488);
	   HAL_Delay(3000);
}

void Motor_stay(void) {
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 1500);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 1500);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 1500);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 1500);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, 1500);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 1500);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 1500);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, 1500);
	  HAL_Delay(1500); 
}

void Motor_SetPWM(Motor_ID motor, uint16_t pwm_us) {
    uint16_t constrained_pwm = constrain_pwm(pwm_us);
    switch(motor) {
        case MOTOR_T1:
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, constrained_pwm);
            break;
        case MOTOR_T2:
            __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, constrained_pwm);
            break;
        case MOTOR_T3:
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, constrained_pwm);
            break;
        case MOTOR_T4:
            __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, constrained_pwm);
            break;
        case MOTOR_T5:
            __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, constrained_pwm);
            break;
        case MOTOR_T6:
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, constrained_pwm);
        case MOTOR_T7:
            __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, constrained_pwm);
            break;
        case MOTOR_T8:
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, constrained_pwm);
            break;
        default:
            break;
    }
}

// �������е��PWM
void Motor_SetAllPWM(uint16_t motor_outputs[MOTOR_COUNT]) {
    if (motor_outputs == NULL) {
        return;
    }
    Motor_SetPWM(MOTOR_T1, motor_outputs[0]);
    Motor_SetPWM(MOTOR_T2, motor_outputs[1]);
    Motor_SetPWM(MOTOR_T3, motor_outputs[2]);
    Motor_SetPWM(MOTOR_T4, motor_outputs[3]);
    Motor_SetPWM(MOTOR_T5, motor_outputs[4]);
    Motor_SetPWM(MOTOR_T6, motor_outputs[5]);
    Motor_SetPWM(MOTOR_T7, motor_outputs[6]);
    Motor_SetPWM(MOTOR_T8, motor_outputs[7]);
		HAL_Delay(1500); 
}

void Motor_StopAll(void) {
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 1500);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 1500);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, 1500);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 1500);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 1500);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 1500);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 1500);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, 1500);
}

